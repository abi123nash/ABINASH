gcc update_server.c -o server -lpthread
gcc update_client.c -o client -lpthread



arm-linux-gnueabihf-gcc update_server.c -o server -lpthread

arm-linux-gnueabihf-gcc update_client.c -o client -lpthread
