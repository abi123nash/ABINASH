#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#define EEPROM_DEVICE "/sys/bus/spi/devices/spi1.0/eeprom" // EEPROM sysfs path
#define EEPROM_SIZE (128 * 1024)   // EEPROM total size in bytes
#define PAGESIZE 256               // EEPROM pagesize in bytes
#define TEST_DATA_SIZE EEPROM_SIZE // Use the full EEPROM size for the test

void write_and_verify_eeprom(const char *device, const char *data, size_t size) {
    int fd = open(device, O_RDWR); // Open for both reading and writing
    if (fd < 0) {
        perror("Error opening EEPROM");
        exit(EXIT_FAILURE);
    }

    char read_data[PAGESIZE];
    for (size_t i = 0; i < size; i += PAGESIZE) {
        // Write 256 bytes at once
        if (pwrite(fd, &data[i], PAGESIZE, i) != PAGESIZE) {
            perror("Error writing to EEPROM");
            close(fd);
            exit(EXIT_FAILURE);
        }

        // Read back the same 256 bytes
        if (pread(fd, read_data, PAGESIZE, i) != PAGESIZE) {
            perror("Error reading from EEPROM");
            close(fd);
            exit(EXIT_FAILURE);
        }

        // Print the addresses and characters written and read (for the first byte of each page)
        printf("Address 0x%05zx: Wrote '%c', Read '%c'\n", i, data[i], read_data[0]);

        // Verify the read data matches the written data
        if (memcmp(&read_data, &data[i], PAGESIZE) != 0) {
            fprintf(stderr, "Data mismatch at offset %zu\n", i);
            close(fd);
            exit(EXIT_FAILURE);
        }
    }

    printf("Successfully wrote and verified %zu bytes (%.2f KB) to EEPROM in %zu pages.\n",
       size, size / 1024.0, size / PAGESIZE);
    close(fd);
}

int main() {
    char *write_data = malloc(TEST_DATA_SIZE); // Allocate memory for the test data
    if (write_data == NULL) {
        perror("Memory allocation failed");
        exit(EXIT_FAILURE);
    }

    // Fill data such that each page has a repeating character
    for (size_t i = 0; i < TEST_DATA_SIZE; i++) {
        /*
         * Determine the character based on the page index
         * i / PAGESIZE gives the page number
         */
        write_data[i] = 'a' + ((i / PAGESIZE) % 4); // Cycle through 'a', 'b', 'c', 'd'
    }

    printf("Writing and verifying data to EEPROM...\n");
    write_and_verify_eeprom(EEPROM_DEVICE, write_data, TEST_DATA_SIZE);

    free(write_data); // Don't forget to free the allocated memory
    return 0;
}

