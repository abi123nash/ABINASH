./net_control dh_enable   # Enable DHCP and disable RSTP
./net_control dh_disable  # Disable DHCP
./net_control rs_enable   # Enable RSTP and disable DHCP
./net_control rs_disable  # Disable RSTP
./net_control statu
