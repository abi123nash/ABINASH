#!/bin/sh

# PHY detection section
PHY0_DETECTED=$(dmesg | grep -q 'davinci_mdio.*phy\[0\]:.*TI DP83822' && echo 1 || echo 0)
PHY1_DETECTED=$(dmesg | grep -q 'davinci_mdio.*phy\[1\]:.*TI DP83822' && echo 1 || echo 0)

if [ "$PHY0_DETECTED" -eq 1 ] && [ "$PHY1_DETECTED" -eq 0 ]; then
    echo "Only PHY0 detected, rebooting..."
    reboot
elif [ "$PHY0_DETECTED" -eq 0 ] && [ "$PHY1_DETECTED" -eq 1 ]; then
    echo "Only PHY1 detected, rebooting..."
    reboot
fi

echo "[INFO] Bringing up interfaces..."
ifconfig eth0 up
ifconfig eth1 up

# Static IPs
ETH0_IP="192.168.0.5"
ETH1_IP="192.168.0.6"
NETMASK="255.255.255.0"
GATEWAY="192.168.0.1"

# Static IP function
static_ip_config() {
    ip addr flush dev eth0
    ip addr flush dev eth1

    # Interface monitoring loop
    prev_eth0_state=""
    prev_eth1_state=""

    while true; do
        # Check if DHCP has been enabled (flag file removed)
        if [ -f "/tmp/DHCP_ENABLE.flag" ]; then
            echo "[INFO] DHCP enabled detected - breaking out of static IP mode"
            break
        fi
        
        # Check if RSTP has been enabled
        if [ -f "/tmp/RSTP_ENABLE.flag" ]; then
            echo "[INFO] RSTP enabled detected - breaking out of static IP mode"
            break
        fi

        eth0_state=$(cat /sys/class/net/eth0/operstate)
        eth1_state=$(cat /sys/class/net/eth1/operstate)

        # --- eth0 logic ---
        if [ "$eth0_state" = "up" ]; then
            if [ "$prev_eth0_state" != "up" ]; then
                echo "[INFO] eth0 is UP — reassigning IP"
                ip addr flush dev eth0
                ip addr add ${ETH0_IP}/24 dev eth0
                ip link set eth0 up
            fi
        else
            if [ "$prev_eth0_state" != "down" ]; then
                echo "[INFO] eth0 is DOWN — removing IP"
                ip addr flush dev eth0
            fi
        fi
        prev_eth0_state=$eth0_state

        # --- eth1 logic ---
        if [ "$eth1_state" = "up" ]; then
            if [ "$prev_eth1_state" != "up" ]; then
                echo "[INFO] eth1 is UP — reassigning IP"
                ip addr flush dev eth1
                ip addr add ${ETH1_IP}/24 dev eth1
                ip link set eth1 up
            fi
        else
            if [ "$prev_eth1_state" != "down" ]; then
                echo "[INFO] eth1 is DOWN — removing IP"
                ip addr flush dev eth1
            fi
        fi
        prev_eth1_state=$eth1_state

        sleep 1
    done
}

# DHCP function
dhcp_config() {
    ip addr flush dev eth0
    ip addr flush dev eth1

    # Get initial link states
    LINK0_PREV=$(cat /sys/class/net/eth0/carrier 2>/dev/null || echo 0)
    LINK1_PREV=$(cat /sys/class/net/eth1/carrier 2>/dev/null || echo 0)
    echo "[DEBUG] Initial link states - eth0: $LINK0_PREV, eth1: $LINK1_PREV"

    log_ip_and_dns() {
        iface=$1
        ip=$(ip -4 -o addr show "$iface" | awk '{print $4}' | cut -d/ -f1)
        [ -n "$ip" ] && echo "[INFO] $iface assigned IP: $ip"

        if grep -q 'nameserver' /etc/resolv.conf; then
            echo "[INFO] DNS configured"
        else
            echo "[WARN] No DNS servers found in /etc/resolv.conf"
        fi
    }

    check_subnet_conflict() {
        IP0=$(ip -4 -o addr show eth0 | awk '{print $4}' | cut -d/ -f1)
        IP1=$(ip -4 -o addr show eth1 | awk '{print $4}' | cut -d/ -f1)

        NET0=$(echo "$IP0" | cut -d. -f1-3)
        NET1=$(echo "$IP1" | cut -d. -f1-3)

        if [ "$NET0" = "$NET1" ] && [ -n "$NET0" ]; then
            echo "[WARN] Subnet conflict: eth0 and eth1 are both on $NET0.x"
        fi
    }

    set_default_route() {
        iface=$1
        echo "[DEBUG] Checking for route on interface: $iface"
        route_line=$(ip route | grep "dev $iface proto")

        if [ -n "$route_line" ]; then
            # Extract the source IP from the route line
            src_ip=$(echo "$route_line" | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}')

            # Derive the default gateway as .1 on the same subnet
            gw=$(echo "$src_ip" | awk -F'.' '{printf "%s.%s.%s.1\n", $1, $2, $3}')

            # Remove any existing default route
            ip route del default 2>/dev/null

            # Add new default route via calculated gateway
            ip route add default via "$gw" dev "$iface"
            ip route
        else
            echo "[WARN] No route found for $iface"
        fi
    }

    manage_dhcp() {
        action=$1
        iface=$2
        pid_file="/var/run/udhcpc.$iface.pid"

        case $action in
            start)
                if [ -f "$pid_file" ]; then
                    kill "$(cat "$pid_file")" 2>/dev/null
                    rm -f "$pid_file"
                fi
                echo "[INFO] Starting DHCP on $iface"
                udhcpc -i $iface -p "$pid_file" -b -q >/dev/null 2>&1
                log_ip_and_dns "$iface"
                ;;
            stop)
                echo "[INFO] Stopping DHCP on $iface"
                if [ -f "$pid_file" ]; then
                    kill "$(cat "$pid_file")" 2>/dev/null
                    rm -f "$pid_file"
                fi
                ifconfig $iface 0.0.0.0
                ;;
        esac
    }

    # Handle initial active links
    if [ "$LINK0_PREV" -eq 1 ]; then
        manage_dhcp start eth0
    fi

    if [ "$LINK1_PREV" -eq 1 ]; then
        manage_dhcp start eth1
    fi

    check_subnet_conflict

    # Set default route preference
    if [ "$LINK0_PREV" -eq 1 ]; then
        set_default_route eth0
    fi
    if [ "$LINK1_PREV" -eq 1 ]; then
        set_default_route eth1
    fi

    echo "[INFO] Starting Ethernet link monitor..."

    while true; do
        # Check if DHCP has been disabled (flag file exists)          
        if [ ! -f "/tmp/DHCP_ENABLE.flag" ]; then
            echo "[INFO] DHCP disabled detected - breaking out of DHCP mode"
            # Clean up DHCP clients before exiting
            manage_dhcp stop eth0
            manage_dhcp stop eth1
            break
        fi
        
        # Check if RSTP has been enabled
        if [ -f "/tmp/RSTP_ENABLE.flag" ]; then
            echo "[INFO] RSTP enabled detected - breaking out of DHCP mode"
            # Clean up DHCP clients before exiting
            manage_dhcp stop eth0
            manage_dhcp stop eth1
            break
        fi

        LINK0=$(cat /sys/class/net/eth0/carrier 2>/dev/null || echo 0)
        LINK1=$(cat /sys/class/net/eth1/carrier 2>/dev/null || echo 0)

        if [ "$LINK0" != "$LINK0_PREV" ]; then
            if [ "$LINK0" -eq 1 ]; then
                echo "[INFO] eth0 link detected"
                manage_dhcp start eth0
                check_subnet_conflict
                set_default_route eth0
            else
                echo "[INFO] eth0 link lost"
                manage_dhcp stop eth0
                if [ "$LINK1" -eq 1 ]; then
                    set_default_route eth1
                fi
            fi
            LINK0_PREV=$LINK0
        fi

        if [ "$LINK1" != "$LINK1_PREV" ]; then
            if [ "$LINK1" -eq 1 ]; then
                echo "[INFO] eth1 link detected"
                manage_dhcp start eth1
                check_subnet_conflict
                if [ "$LINK0" -ne 1 ]; then
                    set_default_route eth1
                fi
            else
                echo "[INFO] eth1 link lost"
                manage_dhcp stop eth1
                if [ "$LINK0" -eq 1 ]; then
                    set_default_route eth0
                fi
            fi
            LINK1_PREV=$LINK1
        fi
    done
}

# RSTP Bridge Setup Function
rstp_setup() 
{
    echo "[INFO] Setting up RSTP bridge..."
    ip addr flush dev eth0
    ip addr flush dev eth1

    INTERFACE1="eth0"
    INTERFACE2="eth1"

    # Clean existing bridge if any
    echo "Cleaning existing bridge br0 if any..."
    brctl delif br0 "$INTERFACE1" 2>/dev/null
    brctl delif br0 "$INTERFACE2" 2>/dev/null
    ifconfig br0 down 2>/dev/null
    brctl delbr br0 2>/dev/null

    # Create new bridge
    echo "Creating new bridge br0..."
    brctl addbr br0
    brctl addif br0 "$INTERFACE1"
    brctl addif br0 "$INTERFACE2"
    brctl stp br0 on
    ifconfig br0 up

    # Configure bridge IP
    echo "Flushing IP from $INTERFACE1..."
    ip addr flush dev "$INTERFACE1"
    ip addr flush dev "$INTERFACE2"

    echo "Assigning IP $ETH0_IP to br0..."
    ip addr add "$ETH0_IP"/24 dev br0

    # Configure RSTP parameters
    echo "Configuring RSTP on br0..."
    mstpctl addbridge br0
    mstpctl setforcevers br0 rstp
    mstpctl setmaxage br0 6
    mstpctl setfdelay br0 4
    mstpctl sethello br0 1
    mstpctl settxholdcount br0 3
    mstpctl setageing br0 15

    # Configure port parameters
    mstpctl setportpathcost br0 "$INTERFACE1" 10
    mstpctl setportpathcost br0 "$INTERFACE2" 20
    mstpctl setportadminedge br0 "$INTERFACE1" yes
    mstpctl setportadminedge br0 "$INTERFACE2" yes
    mstpctl setportautoedge br0 "$INTERFACE1" yes
    mstpctl setportautoedge br0 "$INTERFACE2" yes
    mstpctl setportp2p br0 "$INTERFACE1" yes
    mstpctl setportp2p br0 "$INTERFACE2" yes
    mstpctl setportnetwork br0 "$INTERFACE1" no
    mstpctl setportnetwork br0 "$INTERFACE2" no
    mstpctl setbpduguard br0 "$INTERFACE1" no
    mstpctl setbpduguard br0 "$INTERFACE2" no

    echo "[INFO] RSTP bridge br0 setup complete"
    mstpctl showbridge br0
    mstpctl showportdetail br0 "$INTERFACE1"
    mstpctl showportdetail br0 "$INTERFACE2"

    while true; do
        # Check if RSTP has been disabled (flag file removed)
        if [ ! -f "/tmp/RSTP_ENABLE.flag" ]; then
            echo "[INFO] RSTP disabled detected - breaking out of RSTP mode"
            break
        fi
        
        # Check if DHCP has been enabled (flag file exists)
        if [ -f "/tmp/DHCP_ENABLE.flag" ]; then
            echo "[INFO] DHCP enabled detected - breaking out of RSTP mode"
            break
        fi
        
        sleep 1
    done
}

# RSTP Teardown Function
rstp_teardown() {
    echo "[INFO] Tearing down RSTP bridge..."
    
    INTERFACE1="eth0"
    INTERFACE2="eth1"

    echo "Bringing down br0..."
    ifconfig br0 down

    echo "Disabling STP..."
    brctl stp br0 off

    echo "Removing interfaces from br0..."
    brctl delif br0 "$INTERFACE1"
    brctl delif br0 "$INTERFACE2"

    echo "Deleting bridge br0..."
    brctl delbr br0

    echo "[INFO] RSTP bridge teardown complete."
}

RSTP_FLAG_FILE="/tmp/RSTP_ENABLE.flag"
DHCP_FLAG_FILE="/tmp/DHCP_ENABLE.flag"

while true; do
   
    if [ -f "$RSTP_FLAG_FILE" ]; then
        echo "[INFO] RSTP is ENABLED — setting up RSTP bridge"
        rstp_setup
        rstp_teardown
    elif [ -f "$DHCP_FLAG_FILE" ]; then
        echo "[INFO] DHCP is ENABLED — using DHCP mode"
        dhcp_config
    else
        static_ip_config
    fi

    sleep 1  # Adjust sleep as needed
done

